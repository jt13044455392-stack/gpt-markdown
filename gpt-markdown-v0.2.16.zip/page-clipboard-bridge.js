const E="data-gpt-md-capture",M="data-gpt-md-bridge-ready",T="gpt-markdown-clipboard-bridge";function A(a){var o,d;if(!a)return"";if(typeof a=="string")return a;if(typeof a=="number"||typeof a=="boolean")return String(a);if(Array.isArray(a))return a.map(l=>A(l)).filter(Boolean).join("");if(typeof a=="object")try{if(typeof((o=a.props)==null?void 0:o.children)=="string")return a.props.children;if(Array.isArray((d=a.props)==null?void 0:d.children))return a.props.children.map(l=>A(l)).filter(Boolean).join("");if(typeof a.math=="string")return a.math;if(typeof a.tex=="string")return a.tex;if(typeof a.value=="string")return a.value}catch{return""}return""}function P(a){if(typeof a!="string")return!1;const o=a.trim();return o.length===0?!1:/[\\^_{}=+\-*/<>]/.test(o)||/[a-zA-Z]{2,}/.test(o)}function Z(a){if(!a||!(a instanceof Element))return null;let o=a;for(;o;){const d=Object.keys(o).filter(l=>typeof l=="string"&&(l.startsWith("__reactFiber$")||l.startsWith("__reactProps$")));for(const l of d){const p=o[l];if(!p||typeof p!="object"||"nodeType"in p)continue;let u=p;for(let _=0;_<20&&u;_++){const f=u.memoizedProps||u.pendingProps;if(f&&typeof f=="object"&&!("nodeType"in f)){const m=!!f.displayMode||!!f.isDisplay||!!f.block||f.display===!0,y=[f.math,f.tex,f.latex,f.formula,f.value,f.children,f.code,f.content];for(const b of y){const r=A(b);if(typeof r=="string"&&r.trim().length>0&&P(r))return{latex:r.trim(),isDisplay:m}}}u=u.return}}o=o.parentElement}return null}function k(a=document){a.querySelectorAll(".katex, .katex-display, .math-display, .math-inline, .math-block, [data-math], mjx-container, math, div.math").forEach(d=>{const l=Z(d);if(l){d.setAttribute("data-gpt-md-tex",l.latex),d.setAttribute("data-gpt-md-display",l.isDisplay?"true":"false");const p=d.closest(".katex-display, .math-display, .math-block, div.math");p&&p!==d&&(p.setAttribute("data-gpt-md-tex",l.latex),p.setAttribute("data-gpt-md-display","true"))}})}document.addEventListener("click",a=>{const o=a.target;if(!(o instanceof Element))return;const d=o.closest("section, article, [data-is-streaming]");d&&k(d);const l=o.closest(".katex, .math-display, .math-inline, .math-block, [data-math], mjx-container, math");if(!l)return;const p=Z(l);p&&(l.setAttribute("data-gpt-md-tex",p.latex),l.setAttribute("data-gpt-md-display",p.isDisplay?"true":"false"))},!0);window.setInterval(()=>{k(document)},1e3);const S=window;if(!S.__gptMarkdownClipboardBridge){let a=function(r,t){let s=0;for(let e=t-1;e>=0&&r[e]==="\\";e--)s++;return s%2===1},o=function(r,t,s){let e=r.indexOf(t,s);for(;e!==-1&&a(r,e);)e=r.indexOf(t,e+t.length);return e},d=function(r){if(typeof r!="string")return"";let t=r.trim();for(;t.startsWith("(")&&t.endsWith(")")&&t.length>2;){let s=0,e=!0;for(let n=0;n<t.length-1;n++)if(t[n]==="("?s++:t[n]===")"&&s--,s===0){e=!1;break}if(e)t=t.slice(1,-1).trim();else break}return t},l=function(r){if(typeof r!="string"||!r.trim())return String(r??"");let t=r;t=t.replace(/\(\$\$([a-zA-Z0-9_\-]+\]\[\d+\])\)/g,"([$1)"),t=t.replace(/\$\$([a-zA-Z0-9_\-]+\]\[\d+\])/g,"[$1"),t=t.replace(/\$([^$\n]+)\$ *(\\[a-zA-Z][^$\n]*?) *\$\$(?=\s*\n|\s*$)/gm,(e,n,i)=>`

$$${n} ${i.trim()}$$

`),t=t.replace(/\$([^$\n]*\\[a-zA-Z][^$\n]*)\$ *\$\$(?=\s*\n|\s*$)/gm,(e,n)=>`

$$${n.trim()}$$

`),t=t.replace(/\[\s*(\\mathcal[\s\S]*?)\s*\.?\${1,2}/g,`

$$$1$$

`),t=t.replace(/(?:^|\n)\s*\[\s*(\\mathcal[\s\S]*?)\s*\](?:\s*\n|$)/g,`

$$$1$$

`),t=t.replace(/(?:^|\n)\s*\[\s*(\\[a-zA-Z]+[a-zA-Z0-9_\\\^\-+=\s<>≤≥±,./{}|~*'"']+)\s*\](?:\s*\n|$)/g,(e,n)=>`

$$${n.trim()}$$

`),t=t.replace(/(^|\s)\$\$\s*([a-zA-Z0-9_\\\^\-+=\(\)\s<>≤≥±,]{2,40})\s*(?:;\s*\]|;|\])\s*(?=\*|\#|[\u4e00-\u9fa5])/g,(e,n,i)=>`${n}$${i.trim()}$ `),t=t.replace(/(^|[\u4e00-\u9fa5\s,，。；：:!！*])\(\s*([a-zA-Z0-9_\\\^\-+=\s<>≤≥±,./{}~]*\\[a-zA-Z]+[a-zA-Z0-9_\\\^\-+=\s<>≤≥±,./{}~]*|[a-zA-Z]\([a-zA-Z0-9_,\\/]+\))\s*\)(?=[\u4e00-\u9fa5\s,，。；：:!！*]|$)/g,"$1$$$2$$"),t=t.replace(/(?:^|\n)\s*\[\s*\n+\s*([a-zA-Z0-9_\-\(\)\s\\^_{}=+\-*/,]{1,40}?)\s*\n+\s*\]/g,(e,n)=>{const i=n.trim();return!i.includes(`
`)&&!i.includes("\\boxed")&&!i.includes("\\int")&&!i.includes("=")?`

$${i}$

`:`

$$${i}$$

`}),t=t.replace(/(?:^|\n)\s*\[\s*\n+\s*(\$\$)/g,`

$1`),t=t.replace(/(\$\$)\s*\n+\s*\]\s*(?:\n|$)/g,`$1

`),t=t.replace(/(?:^|\n)\s*\[\s*(\$\$\s*\\boxed\{[\s\S]*?\}\s*\$\$)\s*(?:\]|\$\$)?/g,`

$1

`);let s=0;for(;(s=t.indexOf("\\boxed{",s))!==-1;){if(a(t,s)){s+=7;continue}let e=0,n=-1;for(let i=s+6;i<t.length;i++)if(!a(t,i)){if(t[i]==="{")e++;else if(t[i]==="}"&&--e===0){n=i;break}}if(n!==-1){const i=t.slice(Math.max(0,s-10),s);if(/\[\s*$/.test(i)){const $=s-(i.length-i.lastIndexOf("[")),h=t.slice(s,n+1);let g=n+1;for(;g<t.length&&(t[g]==="]"||t[g]==="$"||t[g]===`
`||t[g]===" ");)g++;t=t.slice(0,$)+`

$$${h}$$

`+t.slice(g),s=$+h.length+8;continue}}s+=7}return t=t.replace(/(\$\$[\s\S]*?\$\$)\s*\$\$/g,"$1"),t=t.replace(/\$\$\s*(\$\$[\s\S]*?\$\$)/g,"$1"),t=t.replace(/\${3,}/g,"$$"),t=t.replace(new RegExp("(?<!\\\\)\\[\\s*(\\\\?[a-zA-Z0-9_\\-\\{\\}]*\\\\(?:text|mathrm)[^\\]]*)\\s*\\]","g"),(e,n)=>n.includes(`
`)?e:`$${n.trim()}$`),t=t.replace(new RegExp("(?<!\\\\[a-zA-Z]+)\\(\\s*([a-zA-Z0-9_\\\\\\^\\-+=\\s<>≤≥±]*\\\\[a-zA-Z]+[a-zA-Z0-9_\\\\\\^\\-+=\\s<>≤≥±]*=[a-zA-Z0-9_\\\\\\^\\-+=\\s<>≤≥±]*)\\s*\\)","g"),(e,n)=>/^\d+(?:[.,]\d+)?$/.test(n.trim())?e:`$${n.trim()}$`),t=t.replace(/(\$\$[\s\S]*?\$\$)\s*([.,，。])?\s*\n*\s*\]/g,"$1$2"),t=t.replace(/\${3,}/g,"$$"),t=t.replace(/([^\n#])\s*\n?\s*(#{1,6}\s+[^\n]+)/g,`$1

$2`),t=t.replace(/([。：:!！\)\*\w])\s*([*•\-]\s+[\u4e00-\u9fa5\w\*])/g,`$1
* $2`),t},p=function(r){if(typeof r!="string"||!r.includes("\\begin{"))return String(r??"");const t=/\\begin\{(array|matrix|pmatrix|bmatrix|vmatrix|Vmatrix|cases|rcases|dcases|align|aligned|align\*|split|gather|gathered|gather\*|eqnarray|eqnarray\*)\}([\s\S]*?)\\end\{\1\}/g;return r.replace(t,(s,e,n)=>{let i=n;return i=i.replace(new RegExp("(?<!\\\\)\\\\\\s+(\\\\hline)","g")," \\\\ $1"),i=i.replace(new RegExp("([0-9a-zA-Z_\\}\\]\\)])(?<!\\\\)\\\\\\s+([0-9a-zA-Z_\\{\\[\\\\])","g"),"$1 \\\\ $2"),i=i.replace(/([^\\\s])\s*\\hline/g,"$1 \\\\ \\hline"),`\\begin{${e}}${i}\\end{${e}}`})},u=function(r){if(typeof r!="string")return"";let t=r.trim();for(t=p(t),t=t.replace(/\\right\$\$\s*\^2/g,"\\right]^2").replace(/\\right\$\$\s*\.?\s*\n?\]?/g,"\\right].$$").replace(/\\right\$\$\s*,?\s*\n?\]?/g,"\\right],$$").replace(/\\right\$\$/g,"\\right]").replace(/\\left\$\$/g,"\\left["),t=t.replace(/\\left\s*\{/g,"\\left\\{").replace(/\\right\s*\}/g,"\\right\\}");t.startsWith("[")&&t.endsWith("]")&&t.length>2;)t=t.slice(1,-1).trim();return t=t.replace(/\n\s*={3,}\s*\n/g," = ").replace(/={3,}/g,"=").replace(/\n\s*-{3,}\s*\n/g," - ").replace(/-{3,}/g,"-"),t=t.replace(/\s*\n\s*/g," ").trim(),t},_=function(r){if(typeof r!="string"||!r.trim())return r;let t=r;return t=t.replace(/\${3,}/g,"$$"),t=t.replace(/\n{2,}\s*(\$\$[\s\S]*?\$\$)\s*\n{2,}/g,`
$1
`),t=t.replace(/([^\n])\n{2,}\s*(\$\$[\s\S]*?\$\$)/g,`$1
$2`),t=t.replace(/(\$\$[\s\S]*?\$\$)\n{2,}\s*([^\n])/g,`$1
$2`),t.replace(/\n{3,}/g,`

`).trim()},f=function(r){if(/(?:^|\s|\n)#+\s/.test(r)||(r.match(/(?:^|\s|\n)[\*\-]\s/g)||[]).length>=2)return!0;const t=r.replace(/\\(?:text|mathrm|mb|rm|ka)\{[^}]*\}/g,"");return!!/[\u4e00-\u9fa5]{3,}/u.test(t)},m=function(r){if(typeof r!="string"||!r.trim())return r;const t=l(r);let s="",e=0;for(;e<t.length;){if(t.startsWith("```",e)){const n=t.indexOf(`
`,e),i=t.indexOf("```",n===-1?t.length:n+1),c=i===-1?t.length:i+3;s+=t.slice(e,c),e=c;continue}if(t.startsWith("\\boxed{",e)){let n=0,i=-1;for(let c=e;c<t.length;c++)if(!a(t,c)&&(t[c]==="{"&&n++,t[c]==="}"&&--n===0)){i=c;break}if(i!==-1){const c=u(t.slice(e,i+1));s+=`$$${c}$$`,e=i+1,e<t.length&&t[e]==="]"?e++:e+1<t.length&&t[e]===`
`&&t[e+1]==="]"&&(e+=2);continue}}if(t.startsWith("$$",e)){const n=o(t,"$$",e+2);if(n!==-1){const i=t.slice(e+2,n);if(f(i)){const $=i.match(/^([a-zA-Z0-9_\\\^\-+=\(\)\s<>≤≥±,]{2,30})\s*(?:;|\]|[\*\-])/);if($&&/[\\^_{}=+\-*/<>≤≥±]/.test($[1])){const h=u($[1]);s+=`$${h}$ `,e=e+2+$[0].length;continue}s+="",e+=2;continue}const c=u(i);s+=`$$${c}$$`,e=n+2,e<t.length&&t[e]==="]"?e++:e+1<t.length&&t[e]===`
`&&t[e+1]==="]"&&(e+=2);continue}}if(t[e]==="$"&&!a(t,e)){const n=o(t,"$",e+1);if(n!==-1&&t[n+1]!=="$"){const i=u(t.slice(e+1,n));s+=`$${i}$`,e=n+1;continue}}if(t.startsWith("\\[",e)){const n=o(t,"\\]",e+2);if(n!==-1){const i=u(t.slice(e+2,n));s+=`$$${i}$$`,e=n+2;continue}}if(t.startsWith("\\(",e)){const n=o(t,"\\)",e+2);if(n!==-1){const i=u(d(t.slice(e+2,n)));s+=`$${i}$`,e=n+2;continue}}if(t[e]==="["&&!t.slice(Math.max(0,e-5),e).endsWith("\\left")&&(t[e+1]===`
`||t.slice(e,e+20).includes(`
`))){let n=t.indexOf(`
]`,e+1);if(n===-1&&(n=o(t,"]",e+1)),n!==-1){const i=t[n]===`
`&&t[n+1]==="]"?n+2:n+1;let c=t.slice(e+1,n).trim();if(c.startsWith("[")&&(c=c.slice(1).trim()),c.endsWith("]")&&(c=c.slice(0,-1).trim()),c.includes(`
`)||/[\\^_{}=+\-*/<>]/.test(c)){const $=u(c);s+=`$$${$}$$`,e=i;continue}}}if(t[e]==="("&&!a(t,e)&&!/[a-zA-Z0-9_\\]$/.test(t.slice(Math.max(0,e-10),e))){let n=0,i=-1;for(let c=e;c<t.length;c++)if(!a(t,c)&&(t[c]==="("&&n++,t[c]===")"&&--n===0)){i=c;break}if(i!==-1){const c=t.slice(e+1,i).trim(),$=d(c);if($&&/[\\^_{}=+\-*/<>≤≥±,]/u.test($)&&!/^\d+(?:[.,]\d+)?$/.test($)){const h=u($);s+=`$${h}$`,e=i+1;continue}}}s+=t[e],e++}return _(s)},y=function(r){const t=document.documentElement.getAttribute(E);t&&(document.documentElement.removeAttribute(E),window.postMessage({source:T,type:"GPT_MD_NATIVE_COPY_RESULT",requestId:t,text:m(r)},window.location.origin))};S.__gptMarkdownClipboardBridge=!0,document.documentElement.setAttribute(M,"true"),window.postMessage({source:T,type:"GPT_MD_BRIDGE_READY"},window.location.origin);try{const r=DataTransfer.prototype,t=r.setData;if(!t.__gptMdPatched){const s=function(e,n){if(e.toLowerCase()==="text/plain"){const i=m(n);y(i),t.call(this,e,i);return}t.call(this,e,n)};s.__gptMdPatched=!0,r.setData=s}}catch{}const b=navigator.clipboard;if(b){const r=[b,Object.getPrototypeOf(b)].filter(Boolean);for(const t of r){if(typeof t.writeText=="function"&&!t.writeText.__gptMdPatched){const s=t.writeText,e=function(n){const i=m(n);return y(i),s.call(this,i)};e.__gptMdPatched=!0,t.writeText=e}if(typeof t.write=="function"&&!t.write.__gptMdPatched){const s=t.write,e=async function(n){try{const i=[];let c="";for(const $ of n)if($.types&&$.types.includes("text/plain")){const g=await(await $.getType("text/plain")).text(),w=m(g);c=w;const z={"text/plain":new Blob([w],{type:"text/plain"})};for(const x of $.types)if(x!=="text/plain")try{z[x]=await $.getType(x)}catch{}i.push(new ClipboardItem(z))}else i.push($);return c&&y(c),s.call(this,i)}catch{return s.call(this,n)}};e.__gptMdPatched=!0,t.write=e}}}}
