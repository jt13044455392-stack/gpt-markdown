const S="data-gpt-md-capture",M="data-gpt-md-bridge-ready",E="gpt-markdown-clipboard-bridge";function A(a){var o,f;if(!a)return"";if(typeof a=="string")return a;if(typeof a=="number"||typeof a=="boolean")return String(a);if(Array.isArray(a))return a.map(l=>A(l)).filter(Boolean).join("");if(typeof a=="object")try{if(typeof((o=a.props)==null?void 0:o.children)=="string")return a.props.children;if(Array.isArray((f=a.props)==null?void 0:f.children))return a.props.children.map(l=>A(l)).filter(Boolean).join("");if(typeof a.math=="string")return a.math;if(typeof a.tex=="string")return a.tex;if(typeof a.value=="string")return a.value}catch{return""}return""}function P(a){if(typeof a!="string")return!1;const o=a.trim();return o.length===0?!1:/[\\^_{}=+\-*/<>]/.test(o)||/[a-zA-Z]{2,}/.test(o)}function k(a){if(!a||!(a instanceof Element))return null;let o=a;for(;o;){const f=Object.keys(o).filter(l=>typeof l=="string"&&(l.startsWith("__reactFiber$")||l.startsWith("__reactProps$")));for(const l of f){const p=o[l];if(!p||typeof p!="object"||"nodeType"in p)continue;let u=p;for(let _=0;_<20&&u;_++){const d=u.memoizedProps||u.pendingProps;if(d&&typeof d=="object"&&!("nodeType"in d)){const m=!!d.displayMode||!!d.isDisplay||!!d.block||d.display===!0,y=[d.math,d.tex,d.latex,d.formula,d.value,d.children,d.code,d.content];for(const b of y){const i=A(b);if(typeof i=="string"&&i.trim().length>0&&P(i))return{latex:i.trim(),isDisplay:m}}}u=u.return}}o=o.parentElement}return null}function Z(a=document){a.querySelectorAll(".katex, .katex-display, .math-display, .math-inline, .math-block, [data-math], mjx-container, math, div.math").forEach(f=>{const l=k(f);if(l){f.setAttribute("data-gpt-md-tex",l.latex),f.setAttribute("data-gpt-md-display",l.isDisplay?"true":"false");const p=f.closest(".katex-display, .math-display, .math-block, div.math");p&&p!==f&&(p.setAttribute("data-gpt-md-tex",l.latex),p.setAttribute("data-gpt-md-display","true"))}})}document.addEventListener("click",a=>{const o=a.target;if(!(o instanceof Element))return;const f=o.closest("section, article, [data-is-streaming]");f&&Z(f);const l=o.closest(".katex, .math-display, .math-inline, .math-block, [data-math], mjx-container, math");if(!l)return;const p=k(l);p&&(l.setAttribute("data-gpt-md-tex",p.latex),l.setAttribute("data-gpt-md-display",p.isDisplay?"true":"false"))},!0);window.setInterval(()=>{Z(document)},1e3);const T=window;if(!T.__gptMarkdownClipboardBridge){let a=function(i,t){let s=0;for(let e=t-1;e>=0&&i[e]==="\\";e--)s++;return s%2===1},o=function(i,t,s){let e=i.indexOf(t,s);for(;e!==-1&&a(i,e);)e=i.indexOf(t,e+t.length);return e},f=function(i){if(typeof i!="string")return"";let t=i.trim();for(;t.startsWith("(")&&t.endsWith(")")&&t.length>2;){let s=0,e=!0;for(let r=0;r<t.length-1;r++)if(t[r]==="("?s++:t[r]===")"&&s--,s===0){e=!1;break}if(e)t=t.slice(1,-1).trim();else break}return t},l=function(i){if(typeof i!="string"||!i.trim())return String(i??"");if(typeof i!="string"||!i.trim())return i;let t=i;t=t.replace(/\(\$\$([a-zA-Z0-9_\-]+\]\[\d+\])\)/g,"([$1)"),t=t.replace(/\$\$([a-zA-Z0-9_\-]+\]\[\d+\])/g,"[$1"),t=t.replace(/\[\s*(\\mathcal[\s\S]*?)\s*\.?\${1,2}/g,`

$$$1$$

`),t=t.replace(/(?:^|\n)\s*\[\s*(\\mathcal[\s\S]*?)\s*\](?:\s*\n|$)/g,`

$$$1$$

`),t=t.replace(/(?:^|\n)\s*\[\s*(\\[a-zA-Z]+[a-zA-Z0-9_\\\^\-+=\s<>≤≥±,./{}|~*'"’]+)\s*\](?:\s*\n|$)/g,(e,r)=>{const n=r.trim();return n.includes("=")||n.includes("\\frac")||n.includes("\\int")||n.includes("\\quad")?`

$$${n}$$

`:`

$$${n}$$

`}),t=t.replace(/(^|\s)\$\$\s*([a-zA-Z0-9_\\\^\-+=\(\)\s<>≤≥±,]{2,40})\s*(?:;\s*\]|;|\])\s*(?=\*|\#|[\u4e00-\u9fa5])/g,(e,r,n)=>`${r}$${n.trim()}$ `),t=t.replace(/(^|[\u4e00-\u9fa5\s,，。；：:!！*])\(\s*([a-zA-Z0-9_\\\^\-+=\s<>≤≥±,./{}~]*\\[a-zA-Z]+[a-zA-Z0-9_\\\^\-+=\s<>≤≥±,./{}~]*|[a-zA-Z]\([a-zA-Z0-9_,\\/]+\))\s*\)(?=[\u4e00-\u9fa5\s,，。；：:!！*]|$)/g,"$1$$$2$$"),t=t.replace(/(\$\$[\s\S]*?\$\$)\s*([.,，。])?\s*\n*\s*\]/g,"$1$2"),t=t.replace(/(?:^|\n)\s*\[\s*\n+\s*([a-zA-Z0-9_\-\(\)\s\\^_{}=+\-*/,]{1,40}?)\s*\n+\s*\]/g,(e,r)=>{const n=r.trim();return!n.includes(`
`)&&!n.includes("\\boxed")&&!n.includes("\\int")&&!n.includes("=")?`

$${n}$

`:`

$$${n}$$

`}),t=t.replace(/(?:^|\n)\s*\[\s*\n+\s*(\$\$)/g,`

$1`),t=t.replace(/(\$\$)\s*\n+\s*\]\s*(?:\n|$)/g,`$1

`),t=t.replace(/(?:^|\n)\s*\[\s*(\$\$\s*\\boxed\{[\s\S]*?\}\s*\$\$)\s*(?:\]|\$\$)?/g,`

$1

`);let s=0;for(;(s=t.indexOf("\\boxed{",s))!==-1;){if(a(t,s)){s+=7;continue}let e=0,r=-1;for(let n=s+6;n<t.length;n++)if(!a(t,n)){if(t[n]==="{")e++;else if(t[n]==="}"&&--e===0){r=n;break}}if(r!==-1){const n=t.slice(Math.max(0,s-10),s);if(/\[\s*$/.test(n)){const $=s-(n.length-n.lastIndexOf("[")),h=t.slice(s,r+1);let g=r+1;for(;g<t.length&&(t[g]==="]"||t[g]==="$"||t[g]===`
`||t[g]===" ");)g++;t=t.slice(0,$)+`

$$${h}$$

`+t.slice(g),s=$+h.length+8;continue}}s+=7}return t=t.replace(/(\$\$[\s\S]*?\$\$)\s*\$\$/g,"$1"),t=t.replace(/\$\$\s*(\$\$[\s\S]*?\$\$)/g,"$1"),t=t.replace(/\${3,}/g,"$$"),t=t.replace(new RegExp("(?<!\\\\)\\[\\s*(\\\\?[a-zA-Z0-9_\\-\\{\\}]*\\\\(?:text|mathrm)[^\\]]*)\\s*\\]","g"),(e,r)=>r.includes(`
`)?e:`$${r.trim()}$`),t=t.replace(new RegExp("(?<!\\\\[a-zA-Z]+)\\(\\s*([a-zA-Z0-9_\\\\\\^\\-+=\\s<>≤≥±]*\\\\[a-zA-Z]+[a-zA-Z0-9_\\\\\\^\\-+=\\s<>≤≥±]*=[a-zA-Z0-9_\\\\\\^\\-+=\\s<>≤≥±]*)\\s*\\)","g"),(e,r)=>/^\d+(?:[.,]\d+)?$/.test(r.trim())?e:`$${r.trim()}$`),t=t.replace(/(\$\$[\s\S]*?\$\$)\s*([.,，。])?\s*\n*\s*\]/g,"$1$2"),t=t.replace(/(\$\$[\s\S]*?\$\$)\s*\$\$/g,"$1"),t=t.replace(/\$\$\s*(\$\$[\s\S]*?\$\$)/g,"$1"),t=t.replace(/\${3,}/g,"$$"),t=t.replace(/([^\n])\s*\n?\s*(#{1,6}\s+[^\n]+)/g,`$1

$2`),t=t.replace(/([。：:!！\)\*\w])\s*([*•\-]\s+[\u4e00-\u9fa5\w\*])/g,`$1
* $2`),t},p=function(i){if(typeof i!="string"||!i.includes("\\begin{"))return String(i??"");const t=/\\begin\{(array|matrix|pmatrix|bmatrix|vmatrix|Vmatrix|cases|rcases|dcases|align|aligned|align\*|split|gather|gathered|gather\*|eqnarray|eqnarray\*)\}([\s\S]*?)\\end\{\1\}/g;return i.replace(t,(s,e,r)=>{let n=r;return n=n.replace(new RegExp("(?<!\\\\)\\\\\\s+(\\\\hline)","g")," \\\\ $1"),n=n.replace(new RegExp("([0-9a-zA-Z_\\}\\]\\)])(?<!\\\\)\\\\\\s+([0-9a-zA-Z_\\{\\[\\\\])","g"),"$1 \\\\ $2"),n=n.replace(/([^\\\s])\s*\\hline/g,"$1 \\\\ \\hline"),`\\begin{${e}}${n}\\end{${e}}`})},u=function(i){if(typeof i!="string")return"";let t=i.trim();for(t=p(t),t=t.replace(/\\right\$\$\s*\^2/g,"\\right]^2").replace(/\\right\$\$\s*\.?\s*\n?\]?/g,"\\right].$$").replace(/\\right\$\$\s*,?\s*\n?\]?/g,"\\right],$$").replace(/\\right\$\$/g,"\\right]").replace(/\\left\$\$/g,"\\left["),t=t.replace(/\\left\s*\{/g,"\\left\\{").replace(/\\right\s*\}/g,"\\right\\}");t.startsWith("[")&&t.endsWith("]")&&t.length>2;)t=t.slice(1,-1).trim();return t=t.replace(/\n\s*={3,}\s*\n/g," = ").replace(/={3,}/g,"=").replace(/\n\s*-{3,}\s*\n/g," - ").replace(/-{3,}/g,"-"),t=t.replace(/\s*\n\s*/g," ").trim(),t},_=function(i){if(typeof i!="string"||!i.trim())return i;let t=i;return t=t.replace(/\${3,}/g,"$$"),t=t.replace(/\n{2,}\s*(\$\$[\s\S]*?\$\$)\s*\n{2,}/g,`
$1
`),t=t.replace(/([^\n])\n{2,}\s*(\$\$[\s\S]*?\$\$)/g,`$1
$2`),t=t.replace(/(\$\$[\s\S]*?\$\$)\n{2,}\s*([^\n])/g,`$1
$2`),t.replace(/\n{3,}/g,`

`).trim()},d=function(i){if(/(?:^|\s|\n)#+\s/.test(i)||(i.match(/(?:^|\s|\n)[\*\-]\s/g)||[]).length>=2)return!0;const t=i.replace(/\\(?:text|mathrm|mb|rm|ka)\{[^}]*\}/g,"");return!!/[\u4e00-\u9fa5]{3,}/u.test(t)},m=function(i){if(typeof i!="string"||!i.trim())return i;const t=l(i);let s="",e=0;for(;e<t.length;){if(t.startsWith("```",e)){const r=t.indexOf(`
`,e),n=t.indexOf("```",r===-1?t.length:r+1),c=n===-1?t.length:n+3;s+=t.slice(e,c),e=c;continue}if(t.startsWith("\\boxed{",e)){let r=0,n=-1;for(let c=e;c<t.length;c++)if(!a(t,c)&&(t[c]==="{"&&r++,t[c]==="}"&&--r===0)){n=c;break}if(n!==-1){const c=u(t.slice(e,n+1));for(s+=`$$${c}$$`,e=n+1;e<t.length&&(t[e]==="]"||t[e]===`
`);){if(t[e]==="]"){e++;break}e++}continue}}if(t.startsWith("$$",e)){const r=o(t,"$$",e+2);if(r!==-1){const n=t.slice(e+2,r);if(d(n)){const $=n.match(/^([a-zA-Z0-9_\\\^\-+=\(\)\s<>≤≥±,]{2,30})\s*(?:;|\]|[\*\-])/);if($&&/[\\^_{}=+\-*/<>≤≥±]/.test($[1])){const h=u($[1]);s+=`$${h}$ `,e=e+2+$[0].length;continue}s+="",e+=2;continue}const c=u(n);for(s+=`$$${c}$$`,e=r+2;e<t.length&&(t[e]==="]"||t[e]===`
`);){if(t[e]==="]"){e++;break}e++}continue}}if(t[e]==="$"&&!a(t,e)){const r=o(t,"$",e+1);if(r!==-1&&t[r+1]!=="$"){const n=u(t.slice(e+1,r));s+=`$${n}$`,e=r+1;continue}}if(t.startsWith("\\[",e)){const r=o(t,"\\]",e+2);if(r!==-1){const n=u(t.slice(e+2,r));s+=`$$${n}$$`,e=r+2;continue}}if(t.startsWith("\\(",e)){const r=o(t,"\\)",e+2);if(r!==-1){const n=u(f(t.slice(e+2,r)));s+=`$${n}$`,e=r+2;continue}}if(t[e]==="["&&!t.slice(Math.max(0,e-5),e).endsWith("\\left")&&(t[e+1]===`
`||t.slice(e,e+20).includes(`
`))){let r=t.indexOf(`
]`,e+1);if(r===-1&&(r=o(t,"]",e+1)),r!==-1){const n=t[r]===`
`&&t[r+1]==="]"?r+2:r+1;let c=t.slice(e+1,r).trim();if(c.startsWith("[")&&(c=c.slice(1).trim()),c.endsWith("]")&&(c=c.slice(0,-1).trim()),c.includes(`
`)||/[\\^_{}=+\-*/<>]/.test(c)){const $=u(c);s+=`$$${$}$$`,e=n;continue}}}if(t[e]==="("&&!a(t,e)&&!/[a-zA-Z0-9_\\]$/.test(t.slice(Math.max(0,e-10),e))){let r=0,n=-1;for(let c=e;c<t.length;c++)if(!a(t,c)&&(t[c]==="("&&r++,t[c]===")"&&--r===0)){n=c;break}if(n!==-1){const c=t.slice(e+1,n).trim(),$=f(c);if($&&/[\\^_{}=+\-*/<>≤≥±,]/u.test($)&&!/^\d+(?:[.,]\d+)?$/.test($)){const h=u($);s+=`$${h}$`,e=n+1;continue}}}s+=t[e],e++}return _(s)},y=function(i){const t=document.documentElement.getAttribute(S);t&&(document.documentElement.removeAttribute(S),window.postMessage({source:E,type:"GPT_MD_NATIVE_COPY_RESULT",requestId:t,text:m(i)},window.location.origin))};T.__gptMarkdownClipboardBridge=!0,document.documentElement.setAttribute(M,"true"),window.postMessage({source:E,type:"GPT_MD_BRIDGE_READY"},window.location.origin);try{const i=DataTransfer.prototype,t=i.setData;if(!t.__gptMdPatched){const s=function(e,r){if(e.toLowerCase()==="text/plain"){const n=m(r);y(n),t.call(this,e,n);return}t.call(this,e,r)};s.__gptMdPatched=!0,i.setData=s}}catch{}const b=navigator.clipboard;if(b){const i=[b,Object.getPrototypeOf(b)].filter(Boolean);for(const t of i){if(typeof t.writeText=="function"&&!t.writeText.__gptMdPatched){const s=t.writeText,e=function(r){const n=m(r);return y(n),s.call(this,n)};e.__gptMdPatched=!0,t.writeText=e}if(typeof t.write=="function"&&!t.write.__gptMdPatched){const s=t.write,e=async function(r){try{const n=[];let c="";for(const $ of r)if($.types&&$.types.includes("text/plain")){const g=await(await $.getType("text/plain")).text(),w=m(g);c=w;const z={"text/plain":new Blob([w],{type:"text/plain"})};for(const x of $.types)if(x!=="text/plain")try{z[x]=await $.getType(x)}catch{}n.push(new ClipboardItem(z))}else n.push($);return c&&y(c),s.call(this,n)}catch{return s.call(this,r)}};e.__gptMdPatched=!0,t.write=e}}}}
